(function (global, factory) {
  if (typeof define === "function" && define.amd) {
    define([], factory);
  } else if (typeof exports !== "undefined") {
    factory();
  } else {
    var mod = {
      exports: {}
    };
    factory();
    global.FileSaver = mod.exports;
  }
})(this, function () {
  "use strict";

  /*
  * FileSaver.js
  * A saveAs() FileSaver implementation.
  *
  * By Eli Grey, http://eligrey.com
  *
  * License : https://github.com/eligrey/FileSaver.js/blob/master/LICENSE.md (MIT)
  * source  : http://purl.eligrey.com/github/FileSaver.js
  */
  // The one and only way of getting global scope in all environments
  // https://stackoverflow.com/q/3277182/1008999
  var _global = typeof window === 'object' && window.window === window ? window : typeof self === 'object' && self.self === self ? self : typeof global === 'object' && global.global === global ? global : void 0;

  function bom(blob, opts) {
    if (typeof opts === 'undefined') opts = {
      autoBom: false
    };else if (typeof opts !== 'object') {
      console.warn('Deprecated: Expected third argument to be a object');
      opts = {
        autoBom: !opts
      };
    } // prepend BOM for UTF-8 XML and text/* types (including HTML)
    // note: your browser will automatically convert UTF-16 U+FEFF to EF BB BF

    if (opts.autoBom && /^\s*(?:text\/\S*|application\/xml|\S*\/\S*\+xml)\s*;.*charset\s*=\s*utf-8/i.test(blob.type)) {
      return new Blob([String.fromCharCode(0xFEFF), blob], {
        type: blob.type
      });
    }

    return blob;
  }

  function download(url, name, opts) {
    var xhr = new XMLHttpRequest();
    xhr.open('GET', url);
    xhr.responseType = 'blob';

    xhr.onload = function () {
      saveAs(xhr.response, name, opts);
    };

    xhr.onerror = function () {
      console.error('could not download file');
    };

    xhr.send();
  }

  function corsEnabled(url) {
    var xhr = new XMLHttpRequest(); // use sync to avoid popup blocker

    xhr.open('HEAD', url, false);

    try {
      xhr.send();
    } catch (e) {}

    return xhr.status >= 200 && xhr.status <= 299;
  } // `a.click()` doesn't work for all browsers (#465)


  function click(node) {
    try {
      node.dispatchEvent(new MouseEvent('click'));
    } catch (e) {
      var evt = document.createEvent('MouseEvents');
      evt.initMouseEvent('click', true, true, window, 0, 0, 0, 80, 20, false, false, false, false, 0, null);
      node.dispatchEvent(evt);
    }
  }

  var saveAs = _global.saveAs || ( // probably in some web worker
  typeof window !== 'object' || window !== _global ? function saveAs() {}
  /* noop */
  // Use download attribute first if possible (#193 Lumia mobile)
  : 'download' in HTMLAnchorElement.prototype ? function saveAs(blob, name, opts) {
    var URL = _global.URL || _global.webkitURL;
    var a = document.createElement('a');
    name = name || blob.name || 'download';
    a.download = name;
    a.rel = 'noopener'; // tabnabbing
    // TODO: detect chrome extensions & packaged apps
    // a.target = '_blank'

    if (typeof blob === 'string') {
      // Support regular links
      a.href = blob;

      if (a.origin !== location.origin) {
        corsEnabled(a.href) ? download(blob, name, opts) : click(a, a.target = '_blank');
      } else {
        click(a);
      }
    } else {
      // Support blobs
      a.href = URL.createObjectURL(blob);
      setTimeout(function () {
        URL.revokeObjectURL(a.href);
      }, 4E4); // 40s

      setTimeout(function () {
        click(a);
      }, 0);
    }
  } // Use msSaveOrOpenBlob as a second approach
  : 'msSaveOrOpenBlob' in navigator ? function saveAs(blob, name, opts) {
    name = name || blob.name || 'download';

    if (typeof blob === 'string') {
      if (corsEnabled(blob)) {
        download(blob, name, opts);
      } else {
        var a = document.createElement('a');
        a.href = blob;
        a.target = '_blank';
        setTimeout(function () {
          click(a);
        });
      }
    } else {
      navigator.msSaveOrOpenBlob(bom(blob, opts), name);
    }
  } // Fallback to using FileReader and a popup
  : function saveAs(blob, name, opts, popup) {
    // Open a popup immediately do go around popup blocker
    // Mostly only available on user interaction and the fileReader is async so...
    popup = popup || open('', '_blank');

    if (popup) {
      popup.document.title = popup.document.body.innerText = 'downloading...';
    }

    if (typeof blob === 'string') return download(blob, name, opts);
    var force = blob.type === 'application/octet-stream';

    var isSafari = /constructor/i.test(_global.HTMLElement) || _global.safari;

    var isChromeIOS = /CriOS\/[\d]+/.test(navigator.userAgent);

    if ((isChromeIOS || force && isSafari) && typeof FileReader !== 'undefined') {
      // Safari doesn't allow downloading of blob URLs
      var reader = new FileReader();

      reader.onloadend = function () {
        var url = reader.result;
        url = isChromeIOS ? url : url.replace(/^data:[^;]*;/, 'data:attachment/file;');
        if (popup) popup.location.href = url;else location = url;
        popup = null; // reverse-tabnabbing #460
      };

      reader.readAsDataURL(blob);
    } else {
      var URL = _global.URL || _global.webkitURL;
      var url = URL.createObjectURL(blob);
      if (popup) popup.location = url;else location.href = url;
      popup = null; // reverse-tabnabbing #460

      setTimeout(function () {
        URL.revokeObjectURL(url);
      }, 4E4); // 40s
    }
  });
  _global.saveAs = saveAs.saveAs = saveAs;

  if (typeof module !== 'undefined') {
    module.exports = saveAs;
  }
});

var JSZipUtils = {};
JSZipUtils._getBinaryFromXHR = function(xhr) {
    // for xhr.responseText, the 0xFF mask is applied by JSZip
    return xhr.response || xhr.responseText;
};

// taken from jQuery
function createStandardXHR() {
    try {
        return new window.XMLHttpRequest();
    }
    catch (e) {}
}

function createActiveXHR() {
    try {
        return new window.ActiveXObject("Microsoft.XMLHTTP");
    }
    catch (e) {}
}

// Create the request object
var createXHR = window.ActiveXObject ?
    function() {
        return createStandardXHR() || createActiveXHR();
    } :
    // For all other browsers, use the standard XMLHttpRequest object
    createStandardXHR;



JSZipUtils.getBinaryContent = function(path, callback, progress) {
    
    try {

        var xhr = createXHR();

        xhr.open('GET', path, true);

        // recent browsers
        if ("responseType" in xhr) {
            xhr.responseType = "arraybuffer";
        }

        // older browser
        if (xhr.overrideMimeType) {
            xhr.overrideMimeType("text/plain; charset=x-user-defined");
        }

        xhr.onreadystatechange = function(evt) {
            var file, err;
            // use `xhr` and not `this`... thanks IE
            if (xhr.readyState === 4) {
                if (xhr.status === 200 || xhr.status === 0) {
                    file = null;
                    err = null;
                    try {
                        file = JSZipUtils._getBinaryFromXHR(xhr);
                    }
                    catch (e) {
                        err = new Error(e);
                    }
                    callback(err, file);
                }
                else {
                    callback(new Error("Ajax error for " + path + " : " + this.status + " " + this.statusText), null);
                }
            }
        };
        if (progress) xhr.onprogress = progress;
        xhr.send();


        return xhr;

    }
    catch (e) {
        callback(new Error(e), null);
    }
};




var urls = [
   "data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAoHCBYWFRgWFhcYGRgaHBocGhwaHBojIRkZGhoaHBwaGSQcIS4lHR4rIRgYJzgmKy80NjU1HCU7QDs0Py40NTEBDAwMEA8QHxISHjQrJSw0NDY0NDQ0NDQ0NDQxNDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NDQ0NP/AABEIANUA7QMBIgACEQEDEQH/xAAcAAABBQEBAQAAAAAAAAAAAAAAAwQFBgcCAQj/xAA+EAACAQIDBgMFCAIBAwQDAAABAgADEQQhMQUGEkFRYSJxgTJCUpGhBxNicrHB0fCC4SMUwvEVM7LSFkOi/8QAGQEAAwEBAQAAAAAAAAAAAAAAAAIDAQQF/8QAIxEAAwEAAwADAAIDAQAAAAAAAAECEQMhMRJBURNhMkJxBP/aAAwDAQACEQMRAD8A2KEITTAhCEACEIQAIQhAAhCEACESr1lRSzMqqNSxAA8yZTtsfaHQp3WiprN19lB6nNvQesxtI1S34XaQeN3pwlJgjVl4r2PDduH8xUECZRtjezEYi4apwofcTwrbvbNv8iZCFv8AxF+RRR+n0PhsSjqGRldToykEfMRefPWA2lWoNxUqjI34Tr+YaMOxl52N9pTCy4lOL8aZH1U5H0I8oKkY+Nrw0yEjNl7cw+IH/FUVjzW9mHmpzknHEawIQhAwIQhAAhCEACEIQAIQhAAhCEACEIQAIQhAAhIzH7dw9H/3KqA/CDdvktzK1tD7Qqa3FGmzn4nPCPOwuT9IrpIdTT8ReJG4/bWHo5VKig/CM2+S3My3aW9WJrXDVOBT7qeEfTM+pMhC8R8n4Unh/Taae8WGZGqCsnCgu5JsVHkc5S9rfaYDdcKn+b/qqg/qfSUrj6+t+nftIjF7NYEvh2tfVCcj+Un9D8+UxXpv8SXZJ7S2lXrtxVndzy4tB+VR4V9BGgEY4bbQPhqrwsPCcv8A5DUSQXhA4ri3W+XzmmnloWyjLE7URcl8R+ki8Rj3fXToJmm4yVxGMROdz0EjcRtVjkvhEYOZyYG9IcYbHVEcOjsrDmD+vWfQX2XbRq4jAh6zmo33jqCdQotZT9fQifO9Nbkcz06+Xebt9juGq08NUWovCDU4kBPisVAJI1A8K695qePBOT/E0SEISpzhCEIAEIQgAQhCABCEIAEIQgAQhOYAUba2/wCEJWlSPZ3OR7gKc/mJTto7w4muTxVXsfdU8K+Vl19YvtjBMjuji9mIzvmBkCPS0g6uHK5i5X6j+ROO6r9PQ4+OM6RzxT3inIIM5KzJsaozw7BnX9/T+JwDPGcCa2Ik2dhZ0I1fFjlGz4pjMdIdQ2Odo7PSqPFYNyYWuO3cdpAmkaK1UazBlBUjQkML26GxMfPUJjaurMrKuZPL1v8AObPI9xmVxJLURCkc50zyUwm71Rxe1ux19eksWA3TQWZ8z0Gn+5R0kQbSKfhsC7+ypMntn7ou5Bdgi9Bmf4H1lnfEUKIsSMvdUXP009ZGYreJ2ypqEHU5t/A+sm7Yymq8RMYHZeHww4rKv4mOfzOcd097VRv+EFiPeOQ+WpHylKIZzxOxY9TnHFNAP7/ekVe6P/Gku2XzB/aFWHFxojX9kgEBe1gfEPW/nLhsPealiLLfgc+6Tk35G97yyPaY0f7+8Vo1WXQ/7lp5GvSdcKfhv0Jm272+rranV8a6C58Q8ifa8mz7nSX/AAONp1V4kYMOfUHowOYPnLTSfhz1Dn0dQhCMIEIQgAQhCABCEIAEIRGtcggGx6xapStZqWkLvTs5K6cNvGuasLZdj1HaUD/ofuqqffA8HFmRpb+5zQ34l9oXHUfvEcThEqqVYAgzjrk+VadUNys+jNW2WjuSCafEWKXHhcAkWJ5HvzkS6lXKMLEagzQNv4RFw3Aw8VMKEPxAkAEdcjn3HlKBtkkKOpJzOtrf7k2vs6orSPr1/EeGJcRM4AiqUyTkCT2F4DCZM4IMkKOzaj6LbzvJHD7v83b0gK7lFbI5SR2XgCXBe66cNxrrfy0+st2A2Ao0UKOp1/vnJqjsxALFQ35s/wDU0jfLqxFVq7QSmMuUjcTtJqosGKdhz87S17R3QpVM1ZkN75ZqexB5eRErG0N0sTSJKKHW+XAbm3dTnfyvN1mcan79Ij/pjfOLJTA5RNK5B4XBBGoIsR5gxyjA6TUWengWKieFhziT4gDSbqRmNi94k9cCNHqFots/A1K54aKNUINiRki/mY5DyFzM1vw3Eu2cNiWOQuPKWjcv/qmctTqBVWwZmOgN8gPf0PhzHlrHuytylWzYh+M68CXCDzPtP9B2lsoUERQqKqqNAoAA+UE2npK7TWJE3/6wt7cLEdcv0/3HdHHI+jZ9DlK3aF5Rc1L053CLdCVqhjHXQ5dDmJI0dqD31t3H8S080v3om4aJSETpVlYXUgxSU0QIQhNAIlUB1isItSqWM1PBuCDG1XAg5r4T9JRK++NRcQ7L4qRawQ5eEZcQNrgm1/WXDYu3qWIHgazDVGyYenMdxOKpR0OaS0SxuGDKUqoCp/tx0Mom8G6zlhwFSlyQWNrX5EczNWIB1zkbj8CoF+XSJWpDxyYzLMNuxY+I8R6aD1komzlTW3kJaBhWc8Kiw5nkP5MXbYtsxme8SXqNqm32VqnhDyFhHlDCqvLPqZIPhSuonHBGTFw4RIqggEiiJNMPAJ2qTxnA1jati4Ngc7R2fRqi1RFfoSMx5HUTMdqYBsNXKXuh8SHqpPPuND/uaG+JlW3xdHpcXEEdDxISdTzXuCOXlCdbKTXxZV6jlidTHGytnVMSwWirVG5kZInd209BcxlhMYWcM9JXQD2CSqsfiIGp7G47TTNib24YIECil2IAX5jL52lfhnbGrlf+qEdm7gqlmxDfeH4FutMeY1f/ACy7SzU6KooVVCqMgAAAB2A0jvD7RVxqIuUVojbIOm/SOM8jx8IeUQakRrF00StOgk9ZgIk7zHRuHZcCJtUiZMFUnQTO2HSHeDxBVgehlnU3F5TqNWn94tI1EFRswrMoy8ibnyEt9NLKB0Fp18CpJ6R5MFIQhOkkEISA3s26cJSDqoZ3bhUE2ANieJrZkZDLvMbw1LXiKbv1sqhh3VkdVaoTakTn3Zei3yz5nKVdXZWDKSrA3BBIIPa3OV/bmNq16zVKzFnbW+gHIKNAo5WnGF2oyWB8SjkdR5H9v0nLc69R3w2lj7NW2HvwVsmJBI+NRmPzAa+Yz85YcdvLhSaa/fKfvGVVC3JJdgoBAF1152mSUKyuLqb/AKjzHKOKBZfGtgVIYMwuF4fET25Dve0k++mD4p/yRun3YtYC3lE2pGULY/2nUnFsQjUzzZfEv08Q+Rl0wG1qNZeKnURx+Eg/PpGcnNlSKPTB1EbVcAp0yklcHWclOkm5YKiAxFDg1jKtiekebVcljK/j8WiKWdgq9T+g6mInr6KilfERhXxQAJJsBzMr2N3mVv8A2hfu38fzIPE4p3zdie3IeQGUtPE36YTe09u6rTIv8R0HkOf91laNMFi7eJzmWbMmdw9JeZUhp7AX5DSdZc/7yg7dP7pG0wd4DadSiRwMQNeE6fLl6S57I3vU2D+E/SZ4TG9XGBdDnEqEzfTesFtNHAsQZzjcSCcpiGzd6KlNvw9JoeyNsrXFxcEW4gQQRfz8jOeppB8c7LDxT1VJNhIbHbeo0cma7/CubevT1tKptbe+q/hS1NeozY+Z5enzmKf0ZTVeF22ntOhhxeo4LckXMn0H7yjbZ3zrVLrS/wCNO3tH15enzlfeqWNySSdSTcnzJ1ido/8AwrPEl72dDFOcixOd88zfrc5zZfs326+IoulQ8TUuEBjqykG3F1I4Tn5TLdi7ArYhuGkhbqdFUcuI6CbFufuyMGrXbid+HisLKoW9gvM6nOV4lW6T53Hxz7LLCEJ1HCEqm/ew6uJpp91YsjMSpNuIEDS+V8vrLXOZjWmy8enz/tDZrISlZGU9GBB81P7iQeK2cy5i7L//AEPMc/T5T6E2ts4Vb8ah16EaeXQ9xKLtfdErdqNyOaNqPynn5HPuZzfKdw6poy3DYhkPEp/gjoY82nt1igVRw39rO4JGnT++UfbT2ZckjwMPay1/OOvfXzkJWQKfEgLDrmPMcj638puLR3XXQru/hfv6js6syKvFa5txcSgX5c9P4lvpuVIK+G2hGRHkRpILd/HsWdDwhWXQDmpBX0txdvmZNxeT0fjSwsOzt7cRTyZg69H19GGfqby37J3soVbBjwOeTaE9jp87TMJ7eIZXFNGqbbpC3HlbrMa3srtWqkqbomS2Nx3b1P0tJh8XUZBTZ2KDRSch6dO0j8ZTvmAe/TzhMrRVDlFUFxHNPEdZJYnCKSevUc5HV8IycrjqJXteG9P0Vv0nvH8owDkT2riiBBUY5wevUHOwjWrjANM4xeoTznSYdj2HUzdFwKmIZpwlAtny6mO0w6jue8X4D/eszTcGqUAO57/xJDC4l0B4HdQfa4Ta4FgMxnzOhj/Abt1qliBwqbeJv2Em8buWRSvSYmoMzxWIcfDbl29YlUvATSfZUzUM5InSoehUgkMp1VhqDPK9daftZnko1iJNvDodJLTtKfWN6+0FXwpZm68h8tTGNXEPVNhfh+FdP8jz9YvQwyqczfyH6X/WVUJeka5G/Ca3T29WwmIWspLBrCol8nS5ytoCMyp5eRN/oqm4ZQw0YAjyIuJ80YeizuEpoxLGyqoJJ6dyZ9H7JR1oUlcWcIgcXvZgoBz55y0M5uVeMeQhCUIhOTOoQAbhwcuY1E4rYdW1lI36xb0cSj0mKsUHFb8LG1xoQQefSO9hb7K9krgI2nEPYPn8P6d5xXKVNHSor4qkLbwbtrUBYCzjRhz7MOY+syrbmxqn3oQU2LHLwgn1FsgJv6sGAIIIPMRhj8Gti1rHtMVOTFRjGz9zKilXquUI0VD4h2LDTnkPnHG3XaiiFApJa3jBNwAeYIN725y+YpLmROK2KlcqjkjiJCkag2Onf5zJp09H+WMpK7ZQjNGU/hYEfIgEfMx7TxdNrWdc+RupB6HisL+RM625uRiKF2QfeoOajxgfiXn6X9JVyNeo1H7GUxPwrN/hbLz0ays0cW6ZK2XQ5j5GOf8A1xlALJxZ58Jtl1sdfmJnxY3yX2aJsrYGGx1DiQNSqoSj2NwXAGZBOYIIOVjy5SvbZ3br4Y+Nbpewdc1Pn8J84w3A34GHrVFrgilVIIKi/wB2wuPFYXYEEXOdrDLM222hXp16YKlalNxkRZgwP0ImvZ9OV00/6PnvF4IajL+/WRtbAm/iIA69fKa7vTuUQDUw4uurJzHdOo7a+czf/oHqVCiIzMLCwztlz6Cbq9KzXyRFJTVfZF+5/aOUw7MbWJJtYefa0ueytw3YcVVggHurYn1JyHpeWHAbFp0RZFA78z5mTq8DUUvZ269RwOOyL82+Wglq2Zu7SpWst2+Jsz/r0k6lH0E7uBpJumxXTEkw4HadlwNJE7c3go4Zb1H8XuoM3byHTubDvM52xvziKt1p/wDCn4c3I7ty/wAQPOPENi6Q+28c64jEqDrWqG9rn22tYxpTwTHNiADnYEFj5629Y7p1FC2CWZs2ZsySdczykhs3Zz1TZFJ6nkPM/tOh0kak/sZ0qQUcK5DoOfc9ZM7K2BUqm9uFfiI18hzlq2JumiWZ/Gw66DyH7mWdKSIOsjVt+DakRexNiJRsUB4/i5/PlLtsrFOx4WIaw15j+ZWcTj0QXZlVe5tLBuvXSpSLoysGPute1uTD3TrkYcSr5ek77WsnIQhO05wkFvbtlsLhy6AFywVb6AkE3I52A0k7IbeXYgxdL7ssVIbiU2uL2IsR0z5THudDTm9mLf8AqTu7tWcs7txcbaaAcPRQLCw0i5Ecbe3Xr4cnjTwcnXNT68vI2kNTZ008S/CToPwnl5aeU5rjXp2xaSwtew946uGIAPGnNGOX+J90/wBtNFwe2KWIollbQeJTa6+f8zGsPi0c2U+IZlWyYDy5juLiOkawb8rD5iT/AKZtRNdont4t9qNHiSl/yuMrj2FPc+9z9n5iZ/Q3nrDE08TVcv8AdvxBMwCNCEAyGTHM/WNOAFwDoT+8XxOAVjcABuvX838x+PwW4S6RvGwNuUMbSD0mv8SnJkPRhyP0PImM94Nz6GIuxWz/ABpk3r19ZiWztoVsNUDoxRxzGjDoRoy9psu5m/FLFgI9qde2a8n6lDz/AC6jvrMpfhJy57RnG3N1a+HJPCXQe+o0H4hqv6SAalxFFN7Myg91vc+WQM+kq+EV+xlXx+59AuXKWYg5rpci3Fw6cUxW16MrTWGM4zZwGdMADO6m/M+7fS2WXnJHdjemvgX8Hipk+Om2h7r8Ld/mDLNtHdt0J4PGB6H65Su4nBg5OmfyYf3oY+qu0bqzGbPu5vNQxicVJvELcSNky36jp3GRknVwKNfwgE53AAuepnzitOrh3FSk7AroyZMPMcxl/qabul9pqPw08XZG0FQewfz/AAHvp5RWidQ13JdK+HZAeY6yKew7mSe1NuYZFs2Ior+Z0HfmZmO8u/yISmGtVf4hfhXy+I+WXeT/AI230EvV2WzaW1KdFC9Vwi9+fZQMyewmebd+0B3JTDKUGnGwu5/Kui+ZufKVXGVatZ+Ou5dul9B0HJR2E9pUrCwyHbU2H+5aYSGU76JNRd2LVGYs2ZJN2OmpPnHFOkOQAjvAYF3ayKznsNPPpLRg9z6hF3YL+H+TNq0hukRO7+x0rPwtnwi9hlcXA8U0TBYVKagADLkBkJANiaWEHAwCHoM2bvlm0iMfvS73FMcA6nNvQaD6yNPXofGq8LtjdqJTF3cKOnXyAzMqu0d7WNxTXhHxNr6D+flKtUrliSSSTzJufrCnRZ9Bl1zmFZ4kvRTFYx3PE7Fj3/bpHuwsRiEcNRd0b8PMd194ecTXZ7KQpUhiARxi2WmQ5Z5Zy77AwqpSFx4jmxOpy/Tl6THTnsfrMNJ2ZUZqNNntxsqlraXIBMdxjshCtFAehI7AkkfQiPp3rxaea/WEIQjCnDoCCCAQdQcwfOU3b+4dKpd6B+7b4fdP/wBfTKXWExpM1U14fPu2dhPRbhqKyMDdTmPVCNYlT2gVBDqzNYgMg9o8rqOemnyE3zH4CnWQpUQOp68u4OoPcTOt4dwHTx4Yl1GfAfbXy5P9D5yVQdEcpkeKxijNQb31065ry6ax/gtphxdxw8uL3Sf2PaSVPc+sOOtWpstFGsS11LMTYAA2YjmTFdq7s8HAVZWUqGVQcs8yoI5g/wDmI6U9YUlO3rY2amrDkR1uPpI+rhGQ8SE5G4tkQRmCO/eP6Vk8BXg7EW+X8iL2vFVJjuGi27mfaRw2o4w5aLV6dqn/ANh69Zq1GorqGUhlYAggggg6EEaifOOJwYJz16j94tu5v5iMEwVbPRBN6bXse6n3T5C2eYm/HSFwvUbNtq3EZ1htj0cRh040BuCVYZEXJsVYf+JiG9W/eIxZKr/xUzqqHNvzNkSOwsPOa1ulvjQNCjTdfuSqItjmuSgajT1AifxuO2+2Z2/F4Qe39yatIF6V6iDOwHjUdx7w7j5Sj4rZ6tys3Vevcc59EU6ysAVIIOhBBB8rSC27upQxF2A4Kh99RqfxjRvPXvNT/Qm/0+fMVs8K13N76cNs7W66C1p5To5ZAKJetuboYlWCCkXu3hZAWB15+7y9q2kk9k/Zs1uPEtbL2ENz/k38fOM6SKNr0z/BbPeo3DTRmPbl3PSXLZW5FrPWPF+Fb28idTLhhtmpS8CKFUWyA7fWOAsk+TQbG+EwSIvCihR0Ai7CKcMSxOJp0l4ncIO+p7Dqewi42KZXv3UJxzD4aaD5gt/3GRWHou5sovy9T/dJK7yYtK+LNVabBOFRcm/Gy3zNvZyIy7RxsHDPWrItOylfFfKyAc7HnnHovHUnP/4+6AEoztwliADZFHNv47GPd3to0aTO9bMBfBlcKe3IHQX851vXvQKbfc4ZuNhk9Qm4uMuAfF35DTrai4jEO5uxv20A9BGmPsR3qxk7iduKzu7EkvrwjQcgCbWA0y5RXFb21GT7tAFv7/vW6DkPOVtqLDVTLFu1ujiMWw4FAW9mZtFHUnr21j/BCu3hs+4O2DicFTdr8af8b35sgHi9VKn1llkJutsBcFR+6Ri12Lsx5sQBkOQsok3OheHLWb0EIQmihCEIAEIQgA2xmESqhSooZTqD200lE21uXVUscOeJCbhC3iU9uLI+d72miQiVKr0ebqfDDsbg3UlKqEH4XFvlf9RIupgSBdG/xb9Af5m94vBU6q8NRFZehGnl0PlKhtfca92w7f4P/wBrfz85GuF/R1R/6F4zLvvDkjrwnkSNf2Mrh2WwYhgRYkDvbn5TTcds2olP7qvQYqCSr8N+AnUXGRU99L3EgsTsJkVHU2RxdTqp7X1U9onyqemUUzXaKm2HAdUCqLsBxWuxBa2d8h6AS2ILSA2hsyrxFipAOYPI/l7yYoCpTRPv/AWPCvFq2RN26ZDXvFp/JLRklJKYDaNSkb03ZPLQ+YORlp2fv24NqyAj4k1+R19DKYVtPIutBUTXqNg2bt+hW9h1J5i+Y8wcxJZGBmE/d+8CQyi4INiLcwRoZZd3N+GRlTEG6HLjAzU/j6jvGTTOe+Frtdl12hQsx7xjXqpTUvUZUQaljb0kBvLv6maYccbDLjYWXn7I1b6CZ5jMbUqtxVHZze+ZyH5RovpESSY0cdUu+i5bY331TDr/AJt/2jX5/KU3F4t6jl3Ysx5k6dh0HlEQs9qMqe2yr56+YAzM3t+FlMx2KUM2A7iQdPaFTiYXA1Ww01zPc9+8fttMf/rU/mcAfIAn9ZHMljbqLy0TnpLkr5ZhzeLYbDs7BVBJJsAoJLE6BQNTLBurubiMawKrw0751HHh7hfjPl9Jte7e6eHwYui8VS3iqMBxHrw8lHYfWVSbI1SRS9z/ALM7cNTF5cxSB+rnl+Uepmn0KCIoRFCqosFUWAHYCLQjqUiLpv0IQhGFCEIQAIQhAAhCEACEIQAIQhADkiVjb2633isaL8BYhmQ+wzD3gPdbuNZaYRXKpYxppp6jP9kbGWnSZcRTP3iv4Q1zfIFSlsmXW/cSnfaPXbjpIUKcILXYZm9wLfDl+03GQ+3t3aGLThrJcj2WU2ZfI8x2NxI/wr5aWXO/swXB7QKZNdl+q+Xbt/TMoAyhlNweYnW9W5FfCEuoNWja/EozXswGnnK7gsW1M5aHUHQ/77xbjToi+iwVMkf8tvqJDG5kg+0Kb028fCTbwkG+XcCxkNi8WyoSgAsQCTrnzk/g2x3SSHBSwzIA6mNKm0KQvYliOgyPrIetVZz4iT0H8CKJhevylFxpek3y0/BaptSo11QBB1A8Xqx0PlaeYbCgHiYcTd9L9T1i1OjytlLVu3unWxfsLZOdRjZBY52yux5WHfMR/wCkib/aZWFQm3oB+gmlbjbgCpavi0PCPYptlxfica26Dnzlx3b3Kw2Fs1vvKvxuBl+RdF89e8tMeZ+2Srk+kJ06YUBVAVQLAAWAHQAaRSEJQiEIQgAQhCABCEIAEIQgAQhCABCEIAEIQgAQhCABCEIAckSjb1/Z9SrgvhwtOpmSNEc9MvZN+YEvcJjSfo005fR817V2TWwz8FZCjWuO47EZGMmzUryIsZ9I7W2RRxKFKyhhyJ1U9VPI5zKN5fs8egGemxdBmMswPxW6dbSVS0dE8ir/AKZ9Sw4Xz6/p/e8eYHBPUcJTRnc6BRcy07s7j1sWeNv+OjpxMM3Ay8A5jvpNc2Fu/Qwi8NFQD7zHNm8z+0JlsWrS6RTt1vs3VeGpi/G2opj2R+cj2vLSaJTpqqhVAVQLAAWAHQARSEqkl4Rqm/QhCE0UIQhAAhCEACEIQAIQhAAhCEACEIQAIQhAAhCEACEIQAIQhAAhCEACEIQA5AnUIQAIQhAAhCEACEIQAIQhAAhCEAP/2Q=="
];
var crn =["loki"];
var created_on =["01-11-2021 12:12:12"];
var filename = "User Images";
//The function is called
compressed_img(urls, filename);

function compressed_img(urls, filename) {
    var zip = new JSZip();
    var count = 0;
    var name = filename + ".zip";
    urls.forEach(function(url,i) {

        JSZipUtils.getBinaryContent(url, function(err, data) {
            if (err) {
                throw err;
            }
            var fname = crn[i]+ "_" +created_on+".jpg";
            
            zip.file(fname, data, {
                binary: true
            });
            count++;
            if (count == urls.length) {
                zip.generateAsync({
                    type: 'blob'
                }).then(function(content) {
                    saveAs(content, name);
                });
            }
        }, function(e) {
            p[e.target.responseURL] = e;
            var total = 0, prog = 0;
            for(prop in p){
              total+=p[prop].total;
                prog+=p[prop].loaded;
            }
            console.log(prog/total);
            p1.value = prog/total;
        });
    });
}

var p={};